import java.io.*;
import java.util.*;

public class Quiz4 {
    public static void main(String[] args) throws IOException {
        
        // TODO: Use the first and the second command line argument (args[0] and args[1]) to read the database and the query file.
        // TODO: Your code goes here
        // TODO: Print the solution to STDOUT
    }
}
