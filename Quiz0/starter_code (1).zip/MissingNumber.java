import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

class MissingNumber {

    public static void main(String[] args) {

        // First command-line argument refers to the number of integers
        // Second command-line argument contains the path to the input file
        // Your program should only print a single integer to the standard output
        // For the sample input, your output should be:
        // 2
    }

}