import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Scanner;

public class SmallestCharacter {
    public static void main(String[] args) {
        // First command-line argument contains the path to the input file
        // Structured as below:
        // Line 0: <query-1> <query-2> <query-3> ...
        // Line 1: <word-1> <word-2> <word-3> ...

        // Your program should print to the standard output.
        // Your output should match the given format character-by-character.
        // For example for the sample input:
        // [1]
        // If there are more than one integer to print then:
        // [1,2,3,4,5]
    }
}
